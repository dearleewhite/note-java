package com.test;

import com.email.EmailApp;
import com.email.service.ExcelService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = EmailApp.class)
public class ExcelTest {

    @Autowired
    public ExcelService excelService;
    @Test
    public void ExcelTest(){
        System.out.println("kaishi");
        excelService.createRecoveryExcel();
    }

}
