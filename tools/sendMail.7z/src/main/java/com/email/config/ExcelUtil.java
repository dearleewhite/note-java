package com.email.config;

import cn.afterturn.easypoi.excel.ExcelExportUtil;
import cn.afterturn.easypoi.excel.entity.ExportParams;
import cn.hutool.core.io.FileUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Workbook;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

/**
 * @author yedh
 */
public class ExcelUtil {

    public static void saveExcel(List<?> list, String title, String sheetName, Class<?> pojoClass, String fileName) {
        ExportParams exportParams = new ExportParams(title, sheetName);
        defaultSave(list, pojoClass, fileName, exportParams);
    }

    public static void delExcel(String fileName) {
        File file = new File(fileName);
        FileUtil.del(file);
    }

    private static void defaultSave(List<?> list, Class<?> pojoClass, String fileName, ExportParams exportParams) {
        Workbook workbook = ExcelExportUtil.exportExcel(exportParams, pojoClass, list);
        if (workbook != null) {
        }
        createExcel(fileName, workbook);
    }

    private static void createExcel(String fileName, Workbook workbook) {
        try {
            FileOutputStream os = new FileOutputStream(fileName);
            workbook.write(os);
            os.close();
        } catch (Exception e) {
//            log.error("SAVE EXCEL ERROR: ", e);
        }
    }
}
