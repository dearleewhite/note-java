package com.email.service;

import com.email.entity.User;
import com.google.common.collect.Maps;

import com.email.config.ExcelUtil;
import org.springframework.stereotype.Component;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
public class ExcelService {
    //模拟数据库
    private static final Map<Long, User> DATABASES = Maps.newConcurrentMap();

    static {
        DATABASES.put(1L, new User(1L, "zhangsan"));
        DATABASES.put(2L, new User(2L, "lisi"));
        DATABASES.put(3L, new User(3L, "wangwu"));
    }

    //获取users
    public User get(Long id) {
        // 我们假设从数据库读取
//        log.info("查询用户【id】= {}", id);
        return DATABASES.get(id);
    }

    //生成Excel文件
    public String createRecoveryExcel(){
        User user = get(1L);
        User user1 = get(2L);
        List<User> list = new ArrayList<>();
        list.add(user);
        list.add(user1);
        String fileName = "renyuan.xls";
        ExcelUtil.saveExcel(list,null,"sheet1",User.class,fileName);
        return  fileName ;
    }



}
